package search;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Search1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Path path =Paths.get("src/text.txt").toAbsolutePath();
		List<String> file1=Files.lines(path).collect(Collectors.toList());
		String search=getInput();
		SearchStr(search,file1);
		
	}
	public static String getInput()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.nextLine();
		return str;

	}
	
	public static void SearchStr(String search,List<String> file1 )throws IOException
	{
		boolean infile=file1.stream().anyMatch(p->p.equalsIgnoreCase(search));
		if (infile)
		{
			System.out.println("yes");
			
		}
		else
		{
			System.out.println("No");
		}
	}

}
